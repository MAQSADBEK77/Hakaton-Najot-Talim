import cart1 from "../../public/cart1.png";
export const carts = [
  {
    img: { cart1 },
    title: "Uylarni tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 1,
  },
  {
    img: { cart1 },
    title: "Ofislarni tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 2,
  },
  {
    img: { cart1 },
    title: "Bog’larni tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 3,
  },
  {
    img: { cart1 },
    title: "Yashil maydonlarni tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 4,
  },
  {
    img: { cart1 },
    title: "Qurilish joylarini tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 5,
  },
  {
    img: { cart1 },
    title: "Umumiy tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 6,
  },
  {
    img: { cart1 },
    title: "Mebellarni tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 7,
  },
  {
    img: { cart1 },
    title: "Mebellarni tozalash",
    param:
      "Biz sizning uyingiz va ofisingiz tozaligi va farovonligi uchun keng ko'lamli xizmatlarni taqdim etamiz.",
    id: 8,
  },
];
export const xomiylar = [
  {
    image: "https://humocard.uz/bitrix/templates/main/img/card2.png",
    href: "#",
  },
  {
    image: "https://kdb.uz/storage/cards/October2021/hNE9Tjbf0qf181qpgGah.jpg",
    href: "#",
  },
  {
    image: "https://www.royaltaxi.uz/brand_img.png",
    href: "#",
  },
  {
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMc55lGDYSWl8XfGbXyNk1_rflliyLmBRmmA&usqp=CAU",
    href: "#",
  },
  {
    image:
      "https://yt3.googleusercontent.com/Zyb4guoh4dLG3SCQ6myUAylfCfwk_RD30rLGZhtsFW-o2v30_j8CuNRYcjoekYXlH11q5YgMuw=s900-c-k-c0x00ffffff-no-rj",
    href: "#",
  },
  {
    image: "https://humocard.uz/bitrix/templates/main/img/card2.png",
    href: "#",
  },
  {
    image: "https://kdb.uz/storage/cards/October2021/hNE9Tjbf0qf181qpgGah.jpg",
    href: "#",
  },
  {
    image: "https://humocard.uz/bitrix/templates/main/img/card2.png",
    href: "#",
  },
  {
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMc55lGDYSWl8XfGbXyNk1_rflliyLmBRmmA&usqp=CAU",
    href: "#",
  },
];
